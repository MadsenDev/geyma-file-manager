"""AI module (BYOK, optional)."""
